﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assessment_2
{
    public partial class Student_info : Form
    {
        public Student_info()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Student_menu childForm1 = new Student_menu();
            childForm1.Show();
            this.Hide();
        }

        private void Student_info_Load(object sender, EventArgs e)
        {

            string jsonFile = File.ReadAllText(@"student.json");
            var json = JsonConvert.DeserializeObject<StudentInfo>(jsonFile);
            // get some logic here for the current user login
            label1.Text = json.studentInfo[0].name;
            label4.Text = json.studentInfo[0].email;

        }
        public class details
        {
            public int id { get; set; }
            public string name { get; set; }
            public string email { get; set; }

        }
        public class StudentInfo
        {
            public List<details> studentInfo { get; set; }
        }
    }
}
