﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace Assessment_2
{
    public partial class Subject_Setup : Form
    {
        public Subject_Setup()
        {
            InitializeComponent();

            Shown += OnShown;
        }

        private void Subject_Setup_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Admin_menu childForm1 = new Admin_menu();
            childForm1.Show();
            this.Hide();
        }

        private void OnShown(object sender, EventArgs e)
        {
            // Combo box is able to show 2 but theyre both blank

            comboBox2.DataSource = JsonOperations.Read().Subjects.OrderBy(subjects => subjects.name).ToList();
        }

        public class JsonOperations
        {
            public static SubectSelection Read() =>
                JsonConvert.DeserializeObject<SubectSelection>(File.ReadAllText("subject.json"));
        }

        public class subjects
        {
            public int id { get; set; }
            public string name { get; set; }
            public override string ToString() => name;

        }
        public class SubectSelection
        {
            public subjects[] Subjects { get; set; }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // need some way to write everything into file
            // File.WriteAllText(@"");
        }
    }
}
